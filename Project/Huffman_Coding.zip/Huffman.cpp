#include <iostream>
#include <string>
#include <unordered_map>
#include <queue>
using namespace std;

struct Node             //Create new struct call 'Node' with characteristics:
{
    char ch;            //Name of the node: 'ch'
    int freq;           //Frequency of the character: 'freq'
    Node *Left;         //Declare pointers for left and right 
    Node *Right;
};
Node *createNode(char ch, int freq, Node *Left, Node *Right)    //Function to create node with (ch, freq, Left and Right)
{
    Node *node = new Node();
                                //Use -> as 'node' is a pointer
    node->ch = ch;              //ch of node = ch that we input
    node->freq = freq;          //freq of node = freq that we input
    node->Left = Left;          //
    node->Right = Right;        //
    
    return node;                //return the node we created 
}
struct comp                     //Create compare structure
{
    bool operator()(Node *L, Node *R)   //Use operator() to create a functor (its like name of the function)
    {
        return L->freq > R->freq;       //Return true if freq of L is > than freq or R
    }                                   //This is MIN_HEAP
};
void huffmanTree(string input_text);
void encode(Node *root, string str, unordered_map<char, string> &huffmanCode);
int main()
{
    string input_text;
    cout << "Input string: ";
    cin >> input_text;
    huffmanTree(input_text);
    return 0;
}

void huffmanTree(string input_text)     //Build the Huffman Tree
{
    unordered_map<char, int> freq;      //Declare the freq of characters (freq)
                                
    for (char ch: input_text)           //for every characters in input_text
    {
        freq[ch]++;                     //Count the frequency of characters in the "input_text" 
    }

    priority_queue<Node*, vector<Node*>, comp> pq;  //Declare pq (priority queue) using priority_queue STL (used for data structure) in MIN_HEAP
    //To use priority (belong to STL) we need 3 components: 
    //type of elements that the queue stores (comparable), containter (random access iterator, dynamic size), boolean function
    /* 
    Boolean function will decide if the pq is MIN_HEAP (smallest on top) or MAX_HEAP (largest on top)
    if the function return true with the first element < second element --> this is MAX_HEAP
    if the function return true with the first element > second element --> this is MIN_HEAP
    */
    
    for (auto& [n_key, n_frequency] : freq)                             //Create loop variable with 2 characteristics : [n_key, n_frequency] got the type as same as 'freq' by using 'auto'
    {
        Node* node = createNode(n_key, n_frequency, nullptr, nullptr);  //Create new node 
        pq.push(node);                                                  //Push node into priority queue
    }   

    int sum;

    while (pq.size()!=1)                //If the pq is not 0
    {
        Node *Left = pq.top();          //Left = lowest freq (at the top)
        pq.pop();                       //pop out
        Node *Right = pq.top();         //Right = the next low freq (at the top)
        pq.pop();                       //pop out

        sum = Left->freq + Right->freq; //Add 2 freq
        Node* node = createNode('\0', sum, Left, Right);    // '\0' is null charater
        pq.push(node);                  //Push into pq
    }

    Node *root = pq.top();              //root is the top of pq
    unordered_map<char, string> huffmanCode;    //huffmanCode
    encode (root, "", huffmanCode);

    cout << "Huffman Code are: " << '\n';
    for (auto& [x_key, x_frequency] : huffmanCode)
    {
        cout << x_key << " " << x_frequency << '\n';
    }
    
    cout << "Original string: " << input_text << '\n';

    string str = " ";
    for (char ch : input_text)
    {
        str += huffmanCode[ch];
    }

    cout << "Encoded string: " << str << '\n';
}

void encode(Node *root, string str, unordered_map<char, string> &huffmanCode)   //Encode the Huffman
{
    if (root == nullptr)                //Check if this is a null pointer
    {
        return;                         //If yes then return as there nothing to do
    }
    if (!root->Left && !root->Right)    //Check if the current node has no right or left children
    {
        huffmanCode[root->ch] = str;    //If it's true, assign the str to ch of root
        return;
    }
    encode (root->Left, str + "0", huffmanCode);     //With left root, assign 0, save in huffmanCode
    encode (root->Right, str + "1", huffmanCode);    //With right root, assign 1, save in huffmanCode
}